<script>
var wanConn = '';
var user_cnt = parseInt("<?ConfigGet(/sys/UserOfEntries)?>");
var user_data_list=[<?ConfigGetArray(/sys/user#/
,name
,disable
,group
)?>];
function sys_user_obj_mapping(name, disable, group)
{
this.name = name;
this.disable = disable;
this.group = group;
}
function sys_user_data_array(data_array, count)
{
var result_data = new Array();
for(var y=0; y<count; y++)
{
result_data[y]=new sys_user_obj_mapping(data_array[y][0],data_array[y][1],data_array[y][2]);
}
return result_data;
}
var user_data = sys_user_data_array(user_data_list, user_cnt);
//group 0:admin 1:poweruser 2:user 99:manufacturer
function get_user_idx_by_group(group)
{
for(var y=0; y<user_cnt; y++)
{
if(user_data[y].group == group)
return y;
}
return -1;
}
</script>
