function isBlank(s)
{
var i=0;
for (i=0; i < s.length;i++)
{
if (s.charCodeAt(i)!=32) break;
}
if (i==s.length) return true;
return false;
}
function jslSetValue(variable,value)
{
//alert(variable);
$(variable).value=$(value).value;
}
function jslDisable(id)
{
$(id).disabled=true;
}
function jslEnable(id)
{
$(id).disabled=false;
}
function jslPostToViewCheckBox(ViewId,PostId)
{
if($(PostId).value=="1")
{
$(ViewId).value="on";
$(ViewId).checked=true;
}
else
{
$(ViewId).value="off";
$(ViewId).checked=false;
}
}
function jslFormSubmit(id)
{
$(id).submit();
}
function isAsciiString2(s)
{
var len= s.length;
var ch;
for( i=0; i< len; i++)
{
ch= s.charCodeAt(i);
if( ch > 0x7f || ch < 0x20)
{
return false;
}
}
return true;
}
function isAsciiString(s)
{
var len= s.length;
var ch;
for( i=0; i< len; i++)
{
ch= s.charCodeAt(i);
if( ch > 0x7f || ch < 0x20 || ch == 0x23 || ch == 0x26)//0x23:# 0x26:&
{
return false;
}
}
return true;
}
function valDoValidateUsrPwd(Name)
{
if((Name.length == 0) || (Name.length > 64))
return false;
return true;
}
function isNumber(n)
{
if (n.length==0) return false;
for (var i=0;i < n.length;i++)
{
if (n.charAt(i) < '0' || n.charAt(i) > '9') return false;
}
return true;
}
function isIP(ip)
{
var sIP=ip.split(".");
if (sIP.length!=4) return false;
for(var i=0; i< sIP.length; i++)
{
if (!isNumber(sIP[i])) return false;
if(i == 3)
if (parseInt(sIP[i]) < 1 || parseInt(sIP[i]) > 254) return false;
else
if (parseInt(sIP[i]) < 0 || parseInt(sIP[i]) > 255) return false;
}
if(parseInt(sIP[0])==0) return false;
return true;
}
function getLeftMostZeroBitPos(num) {
var i = 0;
var numArr = [128, 64, 32, 16, 8, 4, 2, 1];
for ( i = 0; i < numArr.length; i++ )
if ( (num & numArr[i]) == 0 )
return i;
return numArr.length;
}
function getRightMostOneBitPos(num) {
var i = 0;
var numArr = [1, 2, 4, 8, 16, 32, 64, 128];
for ( i = 0; i < numArr.length; i++ )
if ( ((num & numArr[i]) >> i) == 1 )
return (numArr.length - i - 1);
return -1;
}
function isValidSubnetMask(mask) {
var i = 0, num = 0;
var zeroBitPos = 0, oneBitPos = 0;
var zeroBitExisted = false;
if ( mask == '0.0.0.0' )
return false;
maskParts = mask.split('.');
if ( maskParts.length != 4 ) return false;
for (i = 0; i < 4; i++) {
if ( isNaN(maskParts[i]) == true )
return false;
num = parseInt(maskParts[i]);
if ( num < 0 || num > 255 )
return false;
if ( zeroBitExisted == true && num != 0 )
return false;
zeroBitPos = getLeftMostZeroBitPos(num);
oneBitPos = getRightMostOneBitPos(num);
if ( zeroBitPos < oneBitPos )
return false;
if ( zeroBitPos < 8 )
zeroBitExisted = true;
}
return true;
}
function isIPForAdsl(ipAddr)
{
var netWorkIp = new Array("11.0.0.0","129.1.0.0","193.1.1.0");
var broadcastIp = new Array("11.255.255.255","129.1.255.255","193.1.1.255","11.127.255.255");
var classDIp = new Array("224.0.0.1","239.0.0.1");
var classEIp = new Array("240.0.0.1","254.0.0.10");
var lookBackIp = "127.0.0.1";
if(isIP(ipAddr) == false)
return false;
var ipParts = ipAddr.split(".");
var ipAdsl = parseInt(ipParts[0])+"."+parseInt(ipParts[1])+"."+parseInt(ipParts[2])+"."+parseInt(ipParts[3]);
for (i=0; i<netWorkIp.length; i++)
{
if(ipAdsl == netWorkIp[i])
return false;
}
for (j=0; j<broadcastIp.length; j++)
{
if(ipAdsl == broadcastIp[j])
return false;
}
for (k=0; k<classDIp.length; k++)
{
if(ipAdsl == classDIp[k])
return false;
}
for (q=0; q<classEIp.length; q++)
{
if(ipAdsl == classEIp[q])
return false;
}
if (ipAdsl == lookBackIp)
return false;
return true;
}
function isSpeciStaticIpMask(ip,mask)
{
var classBIp = new Array("128.0.0.1","128.255.255.254","136.16.0.1","136.32.255.254","142.64.0.1","142.64.255.255");
var classCIp = new Array("192.0.0.1","192.255.255.254","200.16.32.1");
var subnetMask1 = "255.255.0.0";
var subnetMask2 = "255.255.255.0";
if(isIP(ip) == false)
return false;
var ipParts = ip.split(".");
var ipStic = parseInt(ipParts[0])+"."+parseInt(ipParts[1])+"."+parseInt(ipParts[2])+"."+parseInt(ipParts[3]);
var maskParts = mask.split(".");
var maskStic = parseInt(maskParts[0])+"."+parseInt(maskParts[1])+"."+parseInt(maskParts[2])+"."+parseInt(maskParts[3]);
for (i=0; i<classBIp.length; i++)
{
if(ipStic == classBIp[i])
if(maskStic != subnetMask1)
return false;
}
for (j=0; j<classCIp.length; j++)
{
if(ipStic == classCIp[j])
if(maskStic != subnetMask2)
return false;
}
return true;
}
function isValidIpAddr(ip1,ip2,ip3,ip4)
{
if(ip1==0 || ip4==0 || ip4==255 || ip1==127)
return false;
return true;
}
var ascTable=new Array();
function isHttpChar(a, h)
{
this.a = a;
this.h = h;
}
ascTable[0] = new isHttpChar("#", "%23");
ascTable[1] = new isHttpChar("%", "%25");
ascTable[2] = new isHttpChar("&", "%26");
ascTable[3] = new isHttpChar("+", "%2b");
ascTable[4] = new isHttpChar("/", "%2f");
ascTable[5] = new isHttpChar(":", "%3a");
ascTable[6] = new isHttpChar(";", "%3b");
ascTable[7] = new isHttpChar("<", "%3c");
ascTable[8] = new isHttpChar("=", "%3d");
ascTable[9] = new isHttpChar(">", "%3e");
ascTable[10] = new isHttpChar("?", "%3f");
ascTable[11] = new isHttpChar("@", "%40");
ascTable[12] = new isHttpChar(" ", "%20");
function checkHtmChar(c)
{
for(var i=0; i< ascTable.length; i++)
{
if (c == ascTable[i].a)
return ascTable[i].h;
}
return c;
}
function subHtmAsc(str)
{
var regStr=/(#|%|&|\+|\/|:|;|<|=|>|\?|@|\ )+/;
var rntStr="";
if (str.search(regStr) == -1)
return str;
for(var i=0; i<str.length; i++)
{
rntStr+=checkHtmChar(str.charAt(i))
}
return rntStr;
}
function isHex(cmpStr)
{
var regStr=/[a-fA-F0-9]/;
for(i=0;i<cmpStr.length;i++)
{
if (cmpStr.charAt(i).search(regStr)==-1)
return false;
}
return true;
}
//function valDoValidateIP(Address)
function validIP(Address)
{
var address = Address.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
var digits;
var i;
var error=null;
if(Address == "*")
return true;
if(address == null) {
return false;
}
else
{
digits = address[0].split(".");
for(i=0; i < 4; i++)
{
if((Number(digits[i]) > 255 ) || (Number(digits[i]) < 0 ) || (Number(digits[0]) > 223))
{
return false;
break;
}
}
if(!isValidIpAddr(digits[0],digits[1],digits[2],digits[3],false))
{
return false;
}
}
return true;
}
function isInteger(Integer)
{
if(Integer.match("^[0-9]+$"))
{
return true;
}
return false;
}
function isValidRange(ctrl,start,end)
{
if(ctrl.value.charAt(0) == "0" && ctrl.value.length > 1)
return false;
else if( ctrl.value <start || ctrl.value >end)
return false;
else
return true;
}
function CheckNumericRange(ctrl,start,end, msg)
{
var bNumeric;
var bRange;
var sMsg=msg+" ";
if(ctrl.disabled == true)
return true;
bNumeric = isInteger(ctrl.value);
bRange = isValidRange(ctrl,start,end);
if(!bNumeric || !bRange)
{
if(!bNumeric)
{
sMsg += m_numeric;
}else if(!bRange)
{
sMsg += m_out_of_range;
sMsg += m_range+start+" - "+end+".";
}
dx_alert_error_message( ctrl, sMsg);
return false;
}
return true;
}
function CheckNumericRange2(ctrl,start,end, msg)
{
var bNumeric;
var bRange;
var sMsg=msg;
if(ctrl.disabled == true)
return true;
bNumeric = isInteger(ctrl.value);
bRange = isValidRange(ctrl,start,end);
if(!bNumeric || !bRange)
{
dx_alert_error_message( ctrl, sMsg);
return false;
}
return true;
}
////////////////////////////////////////////////////////////////////
// function dx_alert_error_message( ctrl, msg)
// input:  ctrl: name of the control item
//         msg: error message.
// return: none.
// remark: alert the error message and set the focus to the specified
//         control item.
function dx_alert_error_message( ctrl, msg)
{
alert( msg);
ctrl.focus();
ctrl.select();
}
function dx_alert_error_message_1( ctrl, msg)
{
alert( msg);
ctrl.focus();
}
var hexVals = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
"A", "B", "C", "D", "E", "F");
var unsafeString = "\"<>%\\^[]`\+\$\,'#&";
function isUnsafe(compareChar)
// this function checks to see if a char is URL unsafe.
// Returns bool result. True = unsafe, False = safe
{
if ( unsafeString.indexOf(compareChar) == -1 && compareChar.charCodeAt(0) > 32
&& compareChar.charCodeAt(0) < 123 )
return false; // found no unsafe chars, return false
else
return true;
}
function reversal(s)
// part of the hex-ifying functionality
{
var len = s.length;
var trans = "";
for (i = 0; i < len; i++)
trans = trans + s.substring(len-i-1, len-i);
s = trans;
return s;
}
function decToHex(num, radix)
// part of the hex-ifying functionality
{
var hexString = "";
while ( num >= radix ) {
temp = num % radix;
num = Math.floor(num / radix);
hexString += hexVals[temp];
}
hexString += hexVals[num];
return reversal(hexString);
}
function convert(val)
// this converts a given char to url hex form
{
return  "%" + decToHex(val.charCodeAt(0), 16);
}
function encodeUrl(val)
{
var len     = val.length;
var i       = 0;
var newStr  = "";
var original = val;
for ( i = 0; i < len; i++ ) {
if ( val.substring(i,i+1).charCodeAt(0) < 255 ) {
// hack to eliminate the rest of unicode from this
if (isUnsafe(val.substring(i,i+1)) == false)
newStr = newStr + val.substring(i,i+1);
else
newStr = newStr + convert(val.substring(i,i+1));
} else {
// woopsie! restore.
//alert (m_not_ios_8859_1 + (i+1) + m_not_ios_8859_2);
newStr = original;
// short-circuit the loop and exit
i = len;
}
}
return newStr;
}
/*
function get_obj(name)
{
if ($)	return $(name);//.style;
if (document.all)				return document.all[name].style;
if (document.layers)			return document.layers[name];
}
*/
function is_valid_ip(ipaddr, optional)
{
var ip = get_ip(ipaddr);
if (optional!=0 && is_blank(ipaddr)) return true;
if (is_in_range(ip[1], 1, 223)==false) return false;
if (decstr2int(ip[1]) == 127) return false;
if (is_in_range(ip[2], 0, 255)==false) return false;
if (is_in_range(ip[3], 0, 255)==false) return false;
if (is_in_range(ip[4], 1, 255)==false) return false;
ip[0] = parseInt(ip[1],[10])+"."+parseInt(ip[2],[10])+"."+parseInt(ip[3],[10])+"."+parseInt(ip[4],[10]);
if (ip[0] != ipaddr) return false;
return true;
}
function is_valid_ip_qos(ipaddr, optional)
{
var ip = get_ip(ipaddr);
if (optional!=0 && is_blank(ipaddr)) return true;
if (is_in_range(ip[1], 1, 223)==false) return false;
if (decstr2int(ip[1]) == 127) return false;
if (is_in_range(ip[2], 0, 255)==false) return false;
if (is_in_range(ip[3], 0, 255)==false) return false;
if (is_in_range(ip[4], 0, 255)==false) return false;
ip[0] = parseInt(ip[1],[10])+"."+parseInt(ip[2],[10])+"."+parseInt(ip[3],[10])+"."+parseInt(ip[4],[10]);
if (ip[0] != ipaddr) return false;
return true;
}
function is_valid_multicast_ip(ipaddr, optional)
{
var ip = get_ip(ipaddr);
if (optional!=0 && is_blank(ipaddr)) return true;
if (is_in_range(ip[1], 224, 239)==false) return false;
if (is_in_range(ip[2], 0, 255)==false) return false;
if (is_in_range(ip[3], 0, 255)==false) return false;
if (is_in_range(ip[4], 0, 255)==false) return false;
ip[0] = parseInt(ip[1],[10])+"."+parseInt(ip[2],[10])+"."+parseInt(ip[3],[10])+"."+parseInt(ip[4],[10]);
if (ip[0] != ipaddr) return false;
return true;
}
function get_ip(str_ip)
{
var myIP=new Array();
myIP[0] = myIP[1] = myIP[2] = myIP[3] = myIP[4] = "";
if (str_ip != "")
{
var tmp=str_ip.split(".");
for (var i=1;i <= tmp.length;i++) myIP[i]=tmp[i-1];
myIP[0]=str_ip;
}
else
{
for (var i=0; i <= 4;i++) myIP[i]="";
}
return myIP;
}
function is_valid_mask(mask)
{
var sMask=mask.split(".");
if (sMask.length!=4) return false;
for(var i=0; i< sMask.length; i++)
{
if (!is_digit(sMask[i])) return false;
if (parseInt(sMask[i],10) < 0 || parseInt(sMask[i],10) > 255) return false;
}
for (var i =0 ; i< sMask.length; i++)
sMask[i] = parseInt(sMask[i], 10);
U32ip = sMask[0]*0x1000000+sMask[1]*0x10000+sMask[2]*0x100+sMask[3];
if(U32ip==0) return false;
for(var i=0; i<32;i++)
{
if(U32ip & (0x1<<i))
{
var myvalue = Math.pow(2,i)-1;
myvalue = Math.pow(2,32) -1 -myvalue;
if (myvalue == U32ip)
return true;
else
return false;
}
}
return false;
}
function is_valid_ip2(ipaddr, netmask)
{
var ip_broadcast = get_broadcast_ip(ipaddr, netmask);
if(ip_broadcast[0] == ipaddr) return false;
return true;
}
function get_broadcast_ip(ip, mask)
{
var id = new Array();
var ipaddr = get_ip(ip);
var subnet = get_ip(mask);
id[1] = ipaddr[1] | (subnet[1] ^ 255);
id[2] = ipaddr[2] | (subnet[2] ^ 255);
id[3] = ipaddr[3] | (subnet[3] ^ 255);
id[4] = ipaddr[4] | (subnet[4] ^ 255);
id[0] = id[1]+"."+id[2]+"."+id[3]+"."+id[4];
return id;
}
function is_valid_gateway(ipaddr, netmask, gateway, optional)
{
var ip = get_ip(gateway);
var ip_broadcast = get_broadcast_ip(ipaddr, netmask);
var ip_networkid = get_network_id(ipaddr, netmask);
if (optional!=0 && is_blank(gateway)) return true;
if (is_in_range(ip[1], 1, 223)==false) return false;
if (decstr2int(ip[1]) == 127) return false;
if (is_in_range(ip[2], 0, 255)==false) return false;
if (is_in_range(ip[3], 0, 255)==false) return false;
if (is_in_range(ip[4], 1, 255)==false) return false;
ip[0] = parseInt(ip[1],[10])+"."+parseInt(ip[2],[10])+"."+parseInt(ip[3],[10])+"."+parseInt(ip[4],[10]);
if (ip[0] != gateway) return false;
if(ip_networkid[0] == gateway) return false;
if(ip_broadcast[0] == gateway) return false;
return true;
}
function get_network_id(ip, mask)
{
var id = new Array();
var ipaddr = get_ip(ip);
var subnet = get_ip(mask);
id[1] = ipaddr[1] & subnet[1];
id[2] = ipaddr[2] & subnet[2];
id[3] = ipaddr[3] & subnet[3];
id[4] = ipaddr[4] & subnet[4];
id[0] = id[1]+"."+id[2]+"."+id[3]+"."+id[4];
return id;
}
function is_valid_network(ipaddr, mask)
{
var ip = get_network_id(ipaddr, mask);
if (ip[0] != ipaddr)	return false;
return true;
}
function gen_select_text(obj, obj_value)
{
var inf_idx = -1;
var str = "";
for(var j=0 ;j<obj.length;j++)
{
if(obj_value == obj.options[j].value)
{
inf_idx = j;
break;
}
}
if(inf_idx == -1)
str+="<td align=center> &nbsp; </td>";
else
str+="<td align=center>" +obj.options[j].text+ "</td>";
return str;
}
function is_in_range(str_val, min, max)
{
var d = decstr2int(str_val);
if ( d > max || d < min ) return false;
return true;
}
function is_in_range2(str_val, min, max)
{
var d = decstr2int(str_val);
if ( d >= max || d < min ) return false;
return true;
}
function decstr2int(str)
{
var i = -1;
if (is_digit(str)==true) i = parseInt(str, [10]);
return i;
}
function is_digit(str)
{
if (str.length==0) return false;
for (var i=0;i < str.length;i++)
{
if (str.charAt(i) < '0' || str.charAt(i) > '9') return false;
}
return true;
}
function isValidIpAddress(ipaddr, optional)
{
var ip = get_ip(ipaddr);
//if (optional!=0 && is_blank(ipaddr)) return false;
if(optional == 0 && is_blank(ipaddr))return true;
if (is_in_range(ip[1], 1, 223)==false) return false;
if (decstr2int(ip[1]) == 127) return false;
if (is_in_range(ip[2], 0, 255)==false) return false;
if (is_in_range(ip[3], 0, 255)==false) return false;
if (is_in_range2(ip[4], 1, 255)==false) return false;
ip[0] = parseInt(ip[1],[10])+"."+parseInt(ip[2],[10])+"."+parseInt(ip[3],[10])+"."+parseInt(ip[4],[10]);
if (ip[0] != ipaddr) return false;
return true;
}
function is_blank(s)
{
var i=0;
for(i=0;i<s.length;i++)
{
c=s.charAt(i);
if((c!=' ')&&(c!='\n')&&(c!='\t'))return false;
}
return true;
}
function MathandAbs(ip)
{
var sIP = ip.split(".");
var absip = Math.abs(sIP[0])+"."+Math.abs(sIP[1])+"."+Math.abs(sIP[2])+"."+Math.abs(sIP[3]);
return absip;
}
function isEndIpBigerStartIP(EndIp, StartIp)
{
var addrEnd = EndIp.split('.');
var addrStart = StartIp.split('.');
var valueS = eval(addrStart[0] * 16777216) + eval(addrStart[1] * 65536) + eval(addrStart[2] * 256) + eval(addrStart[3]);
var valueE = eval(addrEnd[0] * 16777216) + eval(addrEnd[1] * 65536) + eval(addrEnd[2] * 256) + eval(addrEnd[3]);
if (valueE <= valueS)
return false;
return true;
}
function isValidMacAddress(address) {
var c = '';
var num = 0;
var i = 0, j = 0;
var zeros = 0;
address = address.replace(/\-/g, ":");
addrParts = address.split(':');
if ( addrParts.length != 6 ) return false;
for (i = 0; i < 6; i++) {
if ( addrParts[i] == '' )
return false;
for ( j = 0; j < addrParts[i].length; j++ ) {
c = addrParts[i].toLowerCase().charAt(j);
if ( (c >= '0' && c <= '9') ||
(c >= 'a' && c <= 'f') )
continue;
else
return false;
}
num = parseInt(addrParts[i], 16);
if ( num == NaN || num < 0 || num > 255 )
return false;
if ( num == 0 )
zeros++;
}
if (zeros == 6)
return false;
if(addrParts[0] == '01')
return false;
return true;
}
function get_text(status){
if(status==0)
status=m_common_disabled;
else
status=m_common_enabled;
return status;
}
function get_text_state(status){
if(status==0)
status=m_state_disabled;
else
status=m_state_enabled;
return status;
}
function isValidIPv6Address(ipaddr)
{
//This will handle this case and return faluse  --> 1:1:1:1:1:1:1:1::
var cqparts = ipaddr.split(":");
if (cqparts.length>9)
{
return false;
}
var i=0;
var first_two_char = ipaddr.substring(0,2);
if (first_two_char == "fe" || first_two_char == "FE" || first_two_char == "Fe" || first_two_char == "fE")
{
return false;
}
// check if there is a '::' in the field
var parts = ipaddr.split("::");
if(parts.length == 1) {
var cqv1 = parts[0].split(":");
for( i=0;i<cqv1.length;i++)
{
if (cqv1[i].length > 4) { //this mean 11111:2001:380:4812:0::  for this case 11111 is wrong, we only accept 4 char len.
return false;
}
}
// there is NO occurence of '::'
var re11 = /^([0]\:){6}\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?$/;
if (re11.test(ipaddr)) {
// IPv4 address in IPv6 address 0:0:0:0:0:0:n.n.n.n/nn e.g. 0:0:0:0:0:0:10.10.10.10/24
var ipv4parts = ipaddr.split(":");
return isValidIPv4Address(ipv4parts[6]);
}
// Pure IPv6 address
var re12 = /^[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}(\/\d{1,2})?$/;
if (re12.test(ipaddr)) {
return true;
}
else {
return false;
}
}
if(parts.length == 2) {
var cqnotail = parts[0].split(":");
if (cqnotail.length == 1 && cqnotail[0].length >5 )
{
return false;
}
var cq = parts[0].split(":");
if ( cq.length >8 && parts[1] == "")
{
return false;
}
if(parts[1] == "")
{
for( i=0;i<cq.length;i++)
{
if (cq[i].length > 4) { //this mean 11111:2001:380:4812:0::  for this case 11111 is wrong, we only accept 4 char len.
return false;
}
}
}
// there is one occurence of '::'
if (parts[0] == "" && parts[1] == "") {
// only :: IPv6 address
return true;
}
// there is one occurence of '::'
if (parts[0] == "") {
// IPv4 address in IPv6 address ::n.n.n.n/nn e.g. :10.10.27.127/24
return isValidIPv4Address(parts[1]);
}
else {
if (parts[0] == "0" || parts[0] == "0:0" || parts[0] == "0:0:0" || parts[0] == "0:0:0:0" || parts[0] == "0:0:0:0:0")
return isValidIPv4Address(parts[1]);
}
if (parts[1] == "") {
// This is for  AAA:: IPv6 address   case
// When  there is nothing followint :: but  the part[0] has the value,  it is OK.
// check second part
// Pure IPv6 address
var cqcqre12 = /^[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}\:[A-Fa-f0-9]{1,4}$/;
if (cqcqre12.test(parts[0])) {
return true;
}
}
// Pure IPv6 address
var v1 = parts[0].split(":");
var v2 = parts[1].split(":");
for( i=0;i<v1.length;i++)
{
if (v1[i].length > 4) { //this mean 11111:2001:380:4812:0::  for this case 11111 is wrong, we only accept 4 char len.
return false;
}
}
for( i=0;i<v2.length;i++)
{
if (v2[i].length > 4) { //this mean 11111:2001:380:4812:0::  for this case 11111 is wrong, we only accept 4 char len.
return false;
}
}
if ((v1.length -1) + (v2.length-1) + 1 >= 7) { //this mean 2001:380:4812:0::280:45ff:fe13:9e49
return false;
}
// check first part
var re21 = /^[A-Fa-f0-9]{1,4}(\:[A-Fa-f0-9]{1,4}){0,5}$/;
if(!re21.test(parts[0])) {
return false
}
if(parts[1] != "") {
// check second part
var re22 = /^([A-Fa-f0-9]{1,4}\:){0,5}[A-Fa-f0-9]{1,4}$/
if(!re22.test(parts[1])) {
return false;
}
}
return true;
}
return false;
} // end function
function isValidIPv4Address(ipaddr) {
var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
if (re.test(ipaddr)) {
var parts = ipaddr.split(".");
if (parseInt(parseFloat(parts[0])) == 0) { return false; }
for (var i=0; i<parts.length; i++) {
if (parseInt(parseFloat(parts[i])) > 255) { return false; }
}
return true;
}
else {
return false;
}
}
function addMacText(mac_id)
{
var mac=document.getElementById(mac_id);
var len= mac.value.length;
mac.value = mac.value.replace(/\-/g, ":");
}
/*Function Name: isValidMacAddr(address[,ismacflt][,fieldname])
Description: Check if value entered is valid mac address or mac filter address
Parameters: address - MAC address to be checked
ismacflt - IS_MAC_FLT (is of type MAC Filter)
IS_NOT_MAC_FLT (not of type MAC Filter)
Default: IS_NOT_MAC_FLT
fieldname - fieldname of the MAC address to be checked
output: true: no error	false: has error
*/
function isValidMacAddr(address,ismacflt,fieldname) {
var c = '';
var i = 0, j = 0;
var hasField;
var additionalComment = " e.g. 00:22:33:AA:BB:CC";
if (fieldname != undefined) hasField = true;
if ((ismacflt == undefined) || (ismacflt == false)){   //can also allow no input at all
if (( address.toLowerCase() == 'ff:ff:ff:ff:ff:ff' ) || ( address.toLowerCase() == '00:00:00:00:00:00' )){
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
}
addrParts = address.split(':');
if ( addrParts.length != 6 ) {
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
for (i = 0; i < 6; i++) {
if ( addrParts[i] == '' ){
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
//one byte can consist of only 2 characters{
if (addrParts[i].length != 2){
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
//}
for ( j = 0; j < addrParts[i].length; j++ ) {
c = addrParts[i].toLowerCase().charAt(j);
if ( (c >= '0' && c <= '9') ||
(c >= 'a' && c <= 'f') )
continue;
else
{
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
}
}
//add checking for multicast mac address
if ((parseInt(addrParts[0], 16) % 2) == 1){
if (hasField) alertInvalid(fieldname,address,additionalComment);
return false;
}
return true;
}
//Add is invalid message
//Function Name: alertInvalid(fieldname, fieldvalue [,additional])
//Description: alerts invalid message containing fieldname and value
//Parameters: fieldname, fieldvalue, additional - Any additional comments to be added
//Output: MessageBox(invalid message)
function alertInvalid(fieldname, fieldvalue, additional)
{
if (additional == undefined)
alert (fieldname + " " + fieldvalue + " is invalid.");
else
alert (fieldname + " " + fieldvalue + " is invalid, " + additional + ".");
}
function cutstr(str,every_len)
{
var total_len=str.length;
var return_str="";
var n=total_len/every_len;
for(var i=0;i<=n;i++)
{
var begin=i*every_len;
var end=(i+1)*every_len;
if(end>total_len)
return_str+=str.substring(begin,total_len);
else
return_str+=str.substring(begin,end)+"<br>";
}
return return_str;
}
function isBlanck2(TelNum)
{
for (var i=0; i<TelNum.length; i++)
{
if((TelNum.charAt(i)==' '))
return false;
}
return true;
}
function isunsafechar(TelNum)
{
for (var i=0; i<TelNum.length; i++)
{
if((TelNum.charCodeAt(i)==34) ||(TelNum.charCodeAt(i)==124)||(TelNum.charCodeAt(i)==62)||(TelNum.charCodeAt(i)==60))
return true;
}
return false;
}
function getId() {
var elements = new Array();
for (var i = 0; i < arguments.length; i++) {
var element = arguments[i];
if (typeof element == 'string')
element = document.getElementById(element);
if (arguments.length == 1)
return element;
elements.push(element);
}
return elements;
}
function changeToAsciiString(s){
var len = s.length;
var tmpArry = "";
for(var i=0; i<len; i++)
{
tmpArry += (s.charCodeAt(i)).toString(16);
}
return tmpArry;
}
