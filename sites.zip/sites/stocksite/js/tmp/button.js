var tmplanguage = "<?ConfigGet(/sys/language)?>";
function bt_apply(fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input type='button' class='button_style' name='save' id='save' value=\""+m_save_settings+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_save_settings+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input type='button' class='button_style_wide' name='save' id='save' value=\""+m_save_settings+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_save_settings+"\" onClick='"+fn+"'>");
}
}
function bt_gen(name,value,fn)
{
if(fn=="")
document.write("<input type='submit' class='button_style' name='"+name+"'value=\""+value+"\">");
else
document.write("<input type='button' class='button_style' name='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
function cancel(fn)
{
if(fn=="")
document.write("<input type='submit' name='cancel' value=\""+m_cancel+"\">");
else
document.write("<input type='button' name='cancel' value=\""+m_cancel+"\" onClick='"+fn+"'>");
}
function bt_wizard_gen(bt_name,bt_value,fn)
{
bt_value = "  "+bt_value+"  ";
document.write("<input class='btn' type='button' name='"+bt_name+"' value=\""+bt_value+"\" onClick='"+fn+"'>");
}
function btn_apply(fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_save_settings+"\">");
else
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_save_settings+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_save_settings+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_save_settings+"\" onClick='"+fn+"'>");
}
}
function btn_apply2(fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_apply_button+"\">");
else
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_apply_button+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_apply_button+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_apply_button+"\" onClick='"+fn+"'>");
}
}
function btn_apply3(btn_value, fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+btn_value+"\">");
else
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+btn_value+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+btn_value+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+btn_value+"\" onClick='"+fn+"'>");
}
}
function btn_edit(fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_edit+"\">");
else
document.write("<input class='button_style' type='button' name='save' id='save' value=\""+m_edit+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_edit+"\">");
else
document.write("<input class='button_style_wide' type='button' name='save' id='save' value=\""+m_edit+"\" onClick='"+fn+"'>");
}
}
function btn_gen(name,value,fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='submit' name='"+name+"'value=\""+value+"\">");
else
document.write("<input class='button_style' type='button' name='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='submit' name='"+name+"'value=\""+value+"\">");
else
document.write("<input class='button_style_wide' type='button' name='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
}
function btn_gen_3(name,value,fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='submit' name='"+name+"' id='"+name+"' value=\""+value+"\">");
else
document.write("<input class='button_style' type='button' name='"+name+"' id='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide' type='submit' name='"+name+"' id='"+name+"' value=\""+value+"\">");
else
document.write("<input class='button_style_wide' type='button' name='"+name+"' id='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
}
function btn_gen_2(name,value,fn)
{
if(tmplanguage=="en")
{
if(fn=="")
document.write("<input class='button_style' type='submit' name='"+name+"'value=\""+value+"\">");
else
document.write("<input class='button_style' type='button' name='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
else
{
if(fn=="")
document.write("<input class='button_style_wide_220' type='submit' name='"+name+"'value=\""+value+"\">");
else
document.write("<input class='button_style_wide_220' type='button' name='"+name+"' value=\""+value+"\" onClick='"+fn+"'>");
}
}
function btn_cancel(fn)
{
if(fn=="")
document.write("<input class='button_style' type='submit' name='cancel' value=\""+m_cancel+"\">");
else
document.write("<input class='button_style' type='button' name='cancel' value=\""+m_cancel+"\" onClick='"+fn+"'>");
}
function btn_remove(fn)
{
if(fn=="")
document.write("<input class='button_style' type='submit' name='remove' value=\""+m_remove+"\">");
else
document.write("<input class='button_style' type='button' name='remove' value=\""+m_remove+"\" onClick='"+fn+"'>");
}
