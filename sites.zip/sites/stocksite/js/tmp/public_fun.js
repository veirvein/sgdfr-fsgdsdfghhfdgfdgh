<script>
setTimeout("testfuc()",1000);
function checkCharacter(rrr)
{
for(var k=0;k<rrr.length;k++)
{
if(rrr.charCodeAt(k)<32 || rrr.charCodeAt(k)>126)
{
alert(m_language_alert);
return false;
}
}
return true;
}
var testfuc=function(){
var lists=document.getElementsByTagName("input");
for(var i=0;i<lists.length && lists[i];i++)
{
if(lists[i].type=="text" || lists[i].type=="textarea" ||lists[i].type=="password")
{
lists[i].onchange=function()
{
/*if(checkCharacter(this.value)==false)
{
this.focus();
this.select();
this.value="";
//setTimeout(function(){this.focus();},1);
}*/
}
}
}
}
var addSpanforRadio=function()
{
var checkList=$("input[type=radio]");
var len=checkList.length;
var radioNameArray=new Array();
for(var i=0;i<len;i++)
{
var check_name=$("input[type=radio]:eq("+i+")").attr("name");
var sameNameFlag = -1;
for(var j=0; j<radioNameArray.length; ++j){
if(radioNameArray[j] == check_name){
sameNameFlag = j;
}
}
if(sameNameFlag == -1) {
radioNameArray.push(check_name);
}
}
//console.log(radioNameArray);
for(var n=0;n<radioNameArray.length;n++)
{
var everyRadioName=radioNameArray[n];
var taglen=$("input[name="+everyRadioName+"]").length;
for(m=0;m<taglen;m++)
{
var check_click_fun=$("input[name="+everyRadioName+"]:eq("+m+")").attr("onclick");
if(check_click_fun)
$("input[name="+everyRadioName+"]:eq("+m+")").wrap("<div id='"+everyRadioName+"_div_"+m+"' click_div='"+check_click_fun+"'>");
else
$("input[name="+everyRadioName+"]:eq("+m+")").wrap("<div id='"+everyRadioName+"_div_"+m+"' click_div=''>");
}
}
}
var initRadioBox=function(radioname,num) {
if(num<0)//just for edit radio
{
$("input[name="+radioname+"]").parent().attr("class", "radio_off");//set all name=radioname radio to "off" status and "checked=false"
$("input[name="+radioname+"]").prop("checked",false);
}
else
{
var checkboxId =  radioname +'_div_'+num;
$("input[name="+radioname+"]").parent().attr("class", "radio_off");//set all name=radioname radio to "off" status and "checked=false"
$("input[name="+radioname+"]").prop("checked",false);
$("#"+checkboxId).attr("class", "radio_on");//just set radio["num"] element to "on" status and "checked=true"
$("input[name="+radioname+"]:eq("+num+")").prop("checked",true);
}
}
var newSpanRadioClick=function () {
$("div.radio_on,div.radio_off").click(function(e){
var check_div_class=$(this).attr("class");
var check_span_id=$(this).attr("id");
var check_name=$(this).children().attr("name");
var id_num=check_span_id.charAt(check_span_id.length-1);
$("input[name="+check_name+"]").parent().attr("class","radio_off");
$("input[name="+check_name+"]").prop("checked",false);
$(this).attr("class","radio_on");
$("input[name="+check_name+"]:eq("+id_num+")").prop("checked",true);
eval($(this).attr("click_div"));
}
);
}
var addDivCheckBox=function()
{
var checkList=$("input[type=checkbox]");
for(var i=0;i<checkList.length;i++)
{
var check_name=$("input[type=checkbox]:eq("+i+")").attr("name");
var check_click_fun=$("input[type=checkbox]:eq("+i+")").attr("onclick");
if(!check_name)
{
var check_name=$("input[type=checkbox]:eq("+i+")").attr("id");
$("input[type=checkbox]:eq("+i+")").attr("name",check_name);
}
else
{
$("input[type=checkbox]:eq("+i+")").attr("id",check_name);
}
if(check_click_fun)
$("input[type=checkbox]:eq("+i+")").wrap("<div  id='"+check_name+"_div' click_div='"+check_click_fun+"'>");
else
$("input[type=checkbox]:eq("+i+")").wrap("<div  id='"+check_name+"_div' click_div=''>");
/*
if(check_click_fun)
$("input[type=checkbox]:eq("+i+")").wrap(gen_on_off_checkbox(check_name+"_chk", check_name, check_click_fun));
else
$("input[type=checkbox]:eq("+i+")").wrap(gen_on_off_checkbox(check_name+"_chk", check_name, ""));
if(baseFilename=="mt_remotelog_tl"||baseFilename=="sp_firewall_ddos_tl")
{
if(check_click_fun)
$("input[type=checkbox]:eq("+i+")").wrap("<div style='float:left' id='"+check_name+"_div' click_div='"+check_click_fun+"'>");
else
$("input[type=checkbox]:eq("+i+")").wrap("<div style='float:left' id='"+check_name+"_div' click_div=''>");
}
else
{
if(check_click_fun)
$("input[type=checkbox]:eq("+i+")").wrap("<div  id='"+check_name+"_div' click_div='"+check_click_fun+"'>");
else
$("input[type=checkbox]:eq("+i+")").wrap("<div  id='"+check_name+"_div' click_div=''>");
}*/
}
}
var initCheckBox=function(id, ck) {
var checkboxId =  id +'_div';
var check_click_fun=$("#"+id).attr("onclick");
if(check_click_fun == undefined)
check_click_fun = "";
if(check_click_fun == "")
$("#"+checkboxId).html("<input type='checkbox' name='"+id+"' id='"+id+"'>");
else
$("#"+checkboxId).html("<input type='checkbox' name='"+id+"' id='"+id+"' onclick='"+check_click_fun+"'>");
if(ck == true) {
$("#"+id).wrap(gen_on_off_checkbox(id+"_chk", id, check_click_fun));
$("#"+id+"_chk_tb").attr("class", "chcekbox_tb");
$("#"+id+"_chk_left").attr("class", "l_tb_ON_left");
$("#"+id+"_chk_left").attr("style", "");
//$("#"+id+"_chk_left").html("ON");
$("#"+id+"_chk_right").attr("class", "l_tb_ON_right");
$("#"+id+"_chk_right").attr("style", "");
//$("#"+id+"_chk_right").html("");
$("#"+id).prop("checked",true);
}else {
$("#"+id).wrap(gen_on_off_checkbox(id+"_chk", id, check_click_fun));
$("#"+id+"_chk_tb").attr("class", "chcekbox_tb");
$("#"+id+"_chk_left").attr("class", "l_tb_OFF_left");
$("#"+id+"_chk_left").attr("style", "");
//$("#"+id+"_chk_left").html("");
$("#"+id+"_chk_right").attr("class", "l_tb_OFF_right");
$("#"+id+"_chk_right").attr("style", "");
//$("#"+id+"_chk_right").html("OFF");
$("#"+id).prop("checked",false);
}
}
var newdivCheckbox=function () {
$("div.checkbox_on,div.checkbox_off").click(function(e){
//alert("click");
var check_div_class=$(this).attr("class");
var check_id=$(this).children().attr("id");
if($("#"+check_id).prop("disabled")==true)
return ;
if(check_div_class=="checkbox_on")
{
$(this).attr("class","checkbox_off");
$("#"+check_id).prop("checked",false);
}
else
{
$(this).attr("class","checkbox_on");
$("#"+check_id).prop("checked",true);
}
eval($(this).attr("click_div"));
}
);
}
var initLanguageButton=function(id, id2,ck) {
var checkboxId =  id +'_div';
if(ck == true) {
$("#"+checkboxId).attr("class", "checkEnbox_on");
$("#"+id2).prop("value","en");
}else {
$("#"+checkboxId).attr("class", "checkEnbox_off");
<?if_node(/runtime/web/logo == "TELSLO")?>
$("#"+id2).prop("value","si");
<?else_node?>
$("#"+id2).prop("value","ru");
<?endif_node?>
}
}
var newdivlanguageButton=function (id2) {
$("div.checkEnbox_on,div.checkEnbox_off").click(function(e){
//console.log("click");
var check_div_class=$(this).attr("class");
var check_id=$(this).children().attr("id");
if(check_div_class=="checkEnbox_on")
{
$(this).attr("class","checkEnbox_off");
<?if_node(/runtime/web/logo == "TELSLO")?>
$("#"+id2).prop("value","si");
<?else_node?>
$("#"+id2).prop("value","ru");
<?endif_node?>
}
else
{
$(this).attr("class","checkEnbox_on");
$("#"+id2).prop("value","en");
}
eval($(this).attr("click_div"));
}
);
}
/*
var BrowserScan=function()
{
var Sys = {};
var ua = navigator.userAgent.toLowerCase();
var s;
var tb_bg_color="";
(s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :
(s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
(s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
(s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] :
(s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] :0;
if (Sys.ie)
{
var ie_v;
if(ua.indexOf("like gecko")!=-1)
{
ie_v = ua.match(/rv\:([\d.]+)/);
if(parseInt(Sys.ie)!=parseInt(ie_v[1]))//sometimes ie11 include "msie",but its real version is not "msie 9.0" but is "rv:11.0"
Sys.ie=ie_v[1];
}
var ne_v=Sys.ie.substring(0,Sys.ie.indexOf(".")+2);
if(ne_v>9)
tb_bg_color="bg_ie10_plus";
else if(ne_v<6)
tb_bg_color="bg_old_browser";
else
tb_bg_color="bg_ie9_minus";
}
else if (Sys.firefox)
{
var ne_v=Sys.firefox.substring(0,Sys.firefox.indexOf(".")+2);
if(ne_v>3.6)
tb_bg_color="bg_firefox";
else
tb_bg_color="bg_old_browser";
}
else if (Sys.chrome)
{
var ne_v=Sys.chrome.substring(0,Sys.chrome.indexOf(".")+2);
if(Sys.chrome>=10)
tb_bg_color="bg_chrome_safari_plus";
else
tb_bg_color="bg_old_chrome_safari";
}
else if (Sys.opera)
{
var ne_v=Sys.opera.substring(0,Sys.opera.indexOf(".")+2);
if(ne_v>=11.1)
tb_bg_color="bg_opera";
else
tb_bg_color="bg_old_browser";
}
else if (Sys.safari)
{
var ne_v=Sys.safari.substring(0,Sys.safari.indexOf(".")+2);
if(ne_v>=4 && ne_v<5.1)
tb_bg_color="bg_old_chrome_safari";
else if(ne_v>=5.1)
tb_bg_color="bg_chrome_safari_plus";
else
tb_bg_color="bg_old_browser";
}
else //others maybe ie11
{
var ie_v;
var ne_v=0;
if(ua.indexOf("like gecko")!=-1)
{
ie_v = ua.match(/rv\:([\d.]+)/);
ne_v=ie_v[1].substring(0,ie_v[1].indexOf(".")+2);
}
if(parseInt(ne_v)>9)//ie11
tb_bg_color="bg_ie10_plus";
else //other browser
tb_bg_color="bg_w3c";
}
if(tb_bg_color=="bg_old_browser")
$(".mytable").attr("style", "background: #d5d5d5");
$(".mytable").height(670);
}
$(function(){
BrowserScan();
$(".centerFillet").html("&nbsp");
}
)*/
/*
addTableListInputText is add the text in td in the table list.
*/
var addTableListInputText=function(id, row, col)
{
for(var i=1; i<=row; i++)
{
for(var j=0; j<col; j++)
{
var tdValue=$("#"+id+" tr:eq("+i+") td:eq("+j+")").html();
if(tdValue.indexOf('type="checkbox"') > -1)
continue;
else if(tdValue.indexOf("type='checkbox'") > -1)
continue;
else if(tdValue.indexOf("type=checkbox") > -1)
continue;
var str = "<input type='text' value='"+tdValue+"' readonly='readonly' class='common special'>";
$("#"+id+" tr:eq("+i+") td:eq("+j+")").html(str);
}
}
}
/*
addTableListInputText is add the text in td in the table list with php file.
*/
var addTableListInputTextWithoutRow=function(id, col)
{
var tdValues = new Array();
var tdValue = "";
var tmpValue = "";
var row = $("#"+id+" tr").length;
if(id == "virtualServerList"){
for(var i=1; i<row; i++)
{
for(var j=0; j<col; j++)
{
if(j == 0)
continue;
tmpValue=$("#"+id+" tr:eq("+i+") td:eq("+j+")").html();
if(tmpValue.indexOf("<\/script>") > -1){
tdValues = tmpValue.split("<\/script>");
tdValue = tdValues[1];
}
else if(tmpValue.indexOf("<\/SCRIPT>") > -1){
tdValues = tmpValue.split("<\/SCRIPT>");
tdValue = tdValues[1];
}
else
tdValue = tmpValue;
var str = "<input type='text' value='"+tdValue+"' readonly='readonly' class='common special'>";
$("#"+id+" tr:eq("+i+") td:eq("+j+")").html(str);
}
}
}
else{
for(var i=1; i<row; i++)
{
for(var j=0; j<col; j++)
{
tmpValue=$("#"+id+" tr:eq("+i+") td:eq("+j+")").html();
if(tmpValue.indexOf('type="checkbox"') > -1)
continue;
else if(tmpValue.indexOf("type='checkbox'") > -1)
continue;
else if(tmpValue.indexOf("type=checkbox") > -1)
continue;
if(tmpValue.indexOf("<\/script>") > -1){
tdValues = tmpValue.split("<\/script>");
tdValue = tdValues[1];
}
else if(tmpValue.indexOf("<\/SCRIPT>") > -1){
tdValues = tmpValue.split("<\/SCRIPT>");
tdValue = tdValues[1];
}
else
tdValue = tmpValue;
var str = "<input type='text' value='"+tdValue+"' readonly='readonly' class='common special'>";
$("#"+id+" tr:eq("+i+") td:eq("+j+")").html(str);
}
}
}
}
var jumpToHomePage = function(){
$("#picHome").css("cursor","pointer").click(function(){
self.location.href = "/status/st_deviceinfo_tl.htm";
}).mouseover(function(){
$(this).attr("src","/graphic/house_color.png");
}).mouseout(function(){
$(this).attr("src","/graphic/house.png");
});
}
function switch_button(name, chk_name)
{
var f = get_obj("frm");
//alert($("#"+name+"_left").attr("class"));
if($("#"+name+"_left").attr("class") == "l_tb_ON_left")
{
$("#"+name+"_left").attr("class", "l_tb_OFF_left");
$("#"+name+"_right").attr("class", "l_tb_OFF_right");
$("#"+chk_name).prop("checked",false);
}
else if($("#"+name+"_left").attr("class") == "l_tb_OFF_left")
{
$("#"+name+"_left").attr("class", "l_tb_ON_left");
$("#"+name+"_right").attr("class", "l_tb_ON_right");
$("#"+chk_name).prop("checked",true);
}
//$("#"+name+"left").attr("class");
}
function gen_on_off_checkbox(name, chk_name, fn)
{
var str ="";
//str += "<table id=\""+name+"_tb\"class=\"chcekbox_tb\">";
str += "<table id=\""+name+"_tb\">";
str += "<tr>"
str += "<td></td>";
if(fn == "")
{
str += "<td style=\"display:none\" id=\""+name+"_left\" class=\"l_tb_OFF_left\" onClick='switch_button(\""+name+"\",\""+chk_name+"\");' ><a></a></td>";
str += "<td style=\"display:none\" id=\""+name+"_right\" class=\"l_tb_OFF_right\" onClick='switch_button(\""+name+"\",\""+chk_name+"\");'><a></a></td>";
}
else
{
str += "<td style=\"display:none\" id=\""+name+"_left\" class=\"l_tb_OFF_left\" onClick='switch_button(\""+name+"\",\""+chk_name+"\");"+fn+";'><a></a></td>";
str += "<td style=\"display:none\" id=\""+name+"_right\" class=\"l_tb_OFF_right\" onClick='switch_button(\""+name+"\",\""+chk_name+"\");"+fn+";'><a></a></td>";
}
str += "</tr></table>";
//document.write(str);
return str;
}
</script>
