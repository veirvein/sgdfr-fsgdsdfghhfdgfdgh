<?IncLang(common/comm.js)?>
<script>
<?Include(/js/common/button.js)?>
<?Include(/js/common/comm.js)?>
<?Include(/js/common/ip.js)?>
<?Include(/js/common/display_tl.js)?>
<?Include(/js/common/logout_tmr.js)?>
</script>
