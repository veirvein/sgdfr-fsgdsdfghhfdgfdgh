var hw_model = parseInt("<?ConfigGet(/runtime/hw/model)?>");
var hw_type = parseInt("<?ConfigGet(/runtime/hw/type)?>");
<?if_node(/runtime/hw/usb == "1")?>var hw_usb = 1;<?else_node?>var hw_usb = 0;<?endif_node?>
<?if_node(/runtime/hw/wifi/enable == "1")?>var hw_wifi = 1;<?else_node?>var hw_wifi = 0;<?endif_node?>
<?if_node(/runtime/hw/xdsl/enable == "1")?>var hw_xdsl = 1;<?else_node?>var hw_xdsl = 0;<?endif_node?>
<?if_node(/runtime/hw/ethwan/enable == "1")?>var hw_ethwan = 1;<?else_node?>var hw_ethwan = 0;<?endif_node?>
<?if_node(/runtime/hw/ethwan_lan/enable == "1")?>var hw_ethwan_lan = 1;<?else_node?>var hw_ethwan_lan = 0;<?endif_node?>
<?if_node(/runtime/hw/sfpwan/enable == "1")?>var hw_sfpwan = 1;<?else_node?>var hw_sfpwan = 0;<?endif_node?>
<?if_node(/runtime/hw/xpon/enable == "1")?>var hw_xpon = 1;<?else_node?>var hw_xpon = 0;<?endif_node?>
<?if_node(/runtime/hw/voip/enable == "1")?>var hw_voip = 1;<?else_node?>var hw_voip = 0;<?endif_node?>
