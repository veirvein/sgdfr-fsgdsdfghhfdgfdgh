function doWizard(){
if(hw_sfpwan == 1)
self.location.href = "/wizard/wiz_sfp_eth.htm";
else
self.location.href = "/wizard/wiz_2_1.htm";
}
function showWireless(arg)
{
for(var i=1; i<=4; i++)
{
if(i == arg)
{
document.getElementsByName("mulssid_2g")[i-1].value = arg;
$("#wl_2g_ssid"+i).show();
}
else
$("#wl_2g_ssid"+i).hide();
}
}
function showWireless_5g(arg)
{
for(var i=1; i<=4; i++)
{
if(i == arg)
{
document.getElementsByName("mulssid_5g")[i-1].value = arg;
$("#wl_5g_ssid"+i).show();
}
else
$("#wl_5g_ssid"+i).hide();
}
}
function ThreeG_Connect() {
var str = "st_deviceinfo_tl.xgi?sessionKey=" + get_sessionKey();
str += "&set/"+wanPath+"Enable=1";
str += "&CMT=0";
str += "&APPLY=1";
self.location = str;
}
function ThreeG_Disconnect() {
var str = "st_deviceinfo_tl.xgi?sessionKey=" + get_sessionKey();
str += "&set/"+wanPath+"Enable=0";
str += "&CMT=0";
str += "&APPLY=1";
self.location = str;
}
function uiDoValidate(){
var f = document.getElementById("frm");
if(valDoValidateUsrPwd(f.ppp_def_name.value)==false)
{
dx_alert_error_message( f.ppp_def_name, e_ppp_name);
return false;
}
if(!isAsciiString(f.ppp_def_name.value))
{
dx_alert_error_message( f.ppp_def_name, e_invalid_ascii);
return false;
}
if(f.ppp_pass.value != l_password)
{
if(valDoValidateUsrPwd(f.ppp_pass.value)==false)
{
dx_alert_error_message( f.ppp_pass, e_ppp_pwd);
return false;
}
if(!isAsciiString(f.ppp_pass.value))
{
dx_alert_error_message( f.ppp_pass, e_invalid_ascii);
return false;
}
}
if(wan_conn_idx == 0 && ppp_idx == 0)
{
alert("The HSI PPP connection is not exist!");
return false;
}
}
function doInternetSetup() {
var f = document.getElementById("frm");
var loc = "";
if (uiDoValidate()==false) return;
loc += "st_show_msg_tl.xgi?";
loc += "sessionKey=" + get_sessionKey();
loc += "&set/InternetGatewayDevice/WANDevice:1/WANConnectionDevice:"+wan_conn_idx+"/WANPPPConnection:"+ppp_idx+"/Username=" + f.ppp_def_name.value;
if(f.ppp_pass.value != l_password)
loc += "&set/InternetGatewayDevice/WANDevice:1/WANConnectionDevice:"+wan_conn_idx+"/WANPPPConnection:"+ppp_idx+"/Password=" + f.ppp_pass.value;
loc += "&CMT=0";
loc += "&APPLY=1";
self.location.href = loc;
}
