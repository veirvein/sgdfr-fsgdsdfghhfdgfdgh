//add login timeout
var logoutTimer = null;
function backToLogin() {
top.logoutFlag = "1";
top.refreshFlag = 1;
var str = "";
str += "logoutTmr.xgi?";
str += "sessionKey=" + get_sessionKey();
self.location.href = str;
}
function restartLogoutTimer() {
if (logoutTimer !== null) {
console.log("Time left is: " + logoutTimer.getTimeLeft() + "seconds.");
logoutTimer.pause();
}
logoutTimer = new log_out_timer(function () {
backToLogin()
}, 300000);
}
function log_out_timer(callback, delay) {
var id, started, remaining = delay, running;
this.start = function () {
running = true;
started = new Date();
id = setTimeout(callback, remaining);
}
this.pause = function () {
running = false;
clearTimeout(id);
remaining -= new Date() - started;
}
this.getTimeLeft = function () {
if (running) {
this.pause();
this.start();
}
return remaining;
}
this.getStateRunning = function () {
return running;
}
this.start();
}
$(document).ready(function() {
restartLogoutTimer();
});
$(document).click(function(e){
restartLogoutTimer();
})