<script>
var physical_type = "<?ConfigGet(/wan/physical_type)?>";
var fw_version = "<?ConfigGet(/InternetGatewayDevice/DeviceInfo/SoftwareVersion)?>";
var fw_build_date = "<?ConfigGet(/InternetGatewayDevice/DeviceInfo/$(X_VENDOR)SoftwareBuildDate)?>";
var tmplanguage = "<?ConfigGet(/sys/language)?>";
var colon = "";
if(tmplanguage == "fr")
colon = " :";
else
colon= ":";
function top_fw_version()
{
return fw_version;
}
function prints(context)
{
document.write(context);
}
function get_obj(name)
{
return document.getElementById(name);
}
function fname()
{
var elements = new Array();
for (var i = 0; i < arguments.length; i++)
{
var element = arguments[i];
if (typeof element == 'string')
element = document.getElementById(element);
if (arguments.length == 1)
return element;
elements.push(element);
}
return elements;
}
</script>
