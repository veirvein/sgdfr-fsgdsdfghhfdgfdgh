<?IncLang(menu.js)?>
<script>
<?Include(/js/common/hw_config.js)?>
<?if_node(/runtime/function/ethwan == "1")?>var func_ethwan = 1;<?else_node?>var func_ethwan = 0;<?endif_node?>
<?if_node(/runtime/function/ethwan_lan == "1")?>var func_ethwan_lan = 1;<?else_node?>var func_ethwan_lan = 0;<?endif_node?>
<?if_node(/runtime/function/sfpwan == "1")?>var func_sfpwan = 1;<?else_node?>var func_sfpwan = 0;<?endif_node?>
<?if_node(/runtime/function/3gwan == "1")?>var func_3gwan = 1;<?else_node?>var func_3gwan = 0;<?endif_node?>
<?if_node(/runtime/function/info == "1")?>var func_info = 1;<?else_node?>var func_info = 0;<?endif_node?>
<?if_node(/runtime/function/waninfo == "1")?>var func_waninfo = 1;<?else_node?>var func_waninfo = 0;<?endif_node?>
<?if_node(/runtime/function/network_setup == "1")?>var func_network_setup = 1;<?else_node?>var func_network_setup = 0;<?endif_node?>
<?if_node(/runtime/function/dsl == "1")?>var func_dsl = 1;<?else_node?>var func_dsl = 0;<?endif_node?>
<?if_node(/runtime/function/arp == "1")?>var func_arp = 1;<?else_node?>var func_arp = 0;<?endif_node?>
<?if_node(/runtime/function/wlan == "1")?>var func_wlan = 1;<?else_node?>var func_wlan = 0;<?endif_node?>
<?if_node(/runtime/function/wlan_11ac == "1")?>var func_wlan_11ac = 1;<?else_node?>var func_wlan_11ac = 0;<?endif_node?>
/* func_wlan_hw_5G: determine wheter to add 5G pages for transition duration */
<?if_node(/runtime/hw/wifi/5G/enable == "1")?>var func_wlan_hw_5G = 1;<?else_node?>var func_wlan_hw_5G = 0;<?endif_node?>
<?if_node(/runtime/function/sipapp == "1")?>var func_sipapp = 1;<?else_node?>var func_sipapp = 0;<?endif_node?>
<?if_node(/runtime/function/route == "1")?>var func_route = 1;<?else_node?>var func_route = 0;<?endif_node?>
<?if_node(/runtime/function/ipv6 == "1")?>var func_ipv6 = 1;<?else_node?>var func_ipv6 = 0;<?endif_node?>
<?if_node(/runtime/function/logs == "1")?>var func_logs = 1;<?else_node?>var func_logs = 0;<?endif_node?>
<?if_node(/runtime/function/wan == "1")?>var func_wan = 1;<?else_node?>var func_wan = 0;<?endif_node?>
<?if_node(/runtime/function/port_map == "1")?>var func_port_map = 1;<?else_node?>var func_port_map = 0;<?endif_node?>
<?if_node(/runtime/function/lan == "1")?>var func_lan = 1;<?else_node?>var func_lan = 0;<?endif_node?>
<?if_node(/runtime/function/virtual_server == "1")?>var func_virtual_server = 1;<?else_node?>var func_virtual_server = 0;<?endif_node?>
<?if_node(/runtime/function/dmz == "1")?>var func_dmz = 1;<?else_node?>var func_dmz = 0;<?endif_node?>
<?if_node(/runtime/function/dhcp == "1")?>var func_dhcp = 1;<?else_node?>var func_dhcp = 0;<?endif_node?>
<?if_node(/runtime/function/dhcpr == "1")?>var func_dhcpr = 1;<?else_node?>var func_dhcpr = 0;<?endif_node?>
<?if_node(/runtime/function/ddns == "1")?>var func_ddns = 1;<?else_node?>var func_ddns = 0;<?endif_node?>
<?if_node(/runtime/function/parent_ctl == "1")?>var func_parent_ctl = 1;<?else_node?>var func_parent_ctl = 0;<?endif_node?>
<?if_node(/runtime/function/ripd == "1")?>var func_ripd = 1;<?else_node?>var func_ripd = 0;<?endif_node?>
<?if_node(/runtime/function/ipsec == "1")?>var func_ipsec = 1;<?else_node?>var func_ipsec = 0;<?endif_node?>
<?if_node(/runtime/function/miniupnpd == "1")?>var func_miniupnpd = 1;<?else_node?>var func_miniupnpd = 0;<?endif_node?>
<?if_node(/runtime/function/mac_filter == "1")?>var func_mac_filter = 1;<?else_node?>var func_mac_filter = 0;<?endif_node?>
<?if_node(/runtime/function/igmp_filter == "1")?>var func_igmp_filter = 1;<?else_node?>var func_igmp_filter = 0;<?endif_node?>
<?if_node(/runtime/function/firewall == "1")?>var func_firewall = 1;<?else_node?>var func_firewall = 0;<?endif_node?>
<?if_node(/runtime/function/qos == "1")?>var func_qos = 1;<?else_node?>var func_qos = 0;<?endif_node?>
<?if_node(/runtime/function/easycwmpd == "1")?>var func_easycwmpd = 1;<?else_node?>var func_easycwmpd = 0;<?endif_node?>
<?if_node(/runtime/function/alg == "1")?>var func_alg = 1;<?else_node?>var func_alg = 0;<?endif_node?>
<?if_node(/runtime/function/samba == "1")?>var func_samba = 1;<?else_node?>var func_samba = 0;<?endif_node?>
<?if_node(/runtime/function/dlna == "1")?>var func_dlna = 1;<?else_node?>var func_dlna = 0;<?endif_node?>
<?if_node(/runtime/function/lpd == "1")?>var func_lpd = 1;<?else_node?>var func_lpd = 0;<?endif_node?>
<?if_node(/runtime/function/users == "1")?>var func_users = 1;<?else_node?>var func_users = 0;<?endif_node?>
<?if_node(/runtime/function/systime == "1")?>var func_systime = 1;<?else_node?>var func_systime = 0;<?endif_node?>
<?if_node(/runtime/function/diagnostic == "1")?>var func_diagnostic = 1;<?else_node?>var func_diagnostic = 0;<?endif_node?>
<?if_node(/runtime/function/access_remote == "1")?>var func_access_remote = 1;<?else_node?>var func_access_remote = 0;<?endif_node?>
<?if_node(/runtime/function/misc == "1")?>var func_misc = 1;<?else_node?>var func_misc = 0;<?endif_node?>
<?if_node(/runtime/function/statistics == "1")?>var func_statistics = 1;<?else_node?>var func_statistics = 0;<?endif_node?>
<?if_node(/runtime/function/tcp_dump == "1")?>var func_tcp_dump = 1;<?else_node?>var func_tcp_dump = 0;<?endif_node?>
<?if_node(/runtime/function/mirror == "1")?>var func_mirror = 1;<?else_node?>var func_mirror = 0;<?endif_node?>
<?if_node(/runtime/function/iperf == "1")?>var func_iperf = 1;<?else_node?>var func_iperf = 0;<?endif_node?>
<?if_node(/runtime/function/bandwidth == "1")?>var func_bandwidth = 1;<?else_node?>var func_bandwidth = 0;<?endif_node?>
<?if_node(/runtime/function/system == "1")?>var func_system = 1;<?else_node?>var func_system = 0;<?endif_node?>
<?if_node(/runtime/function/fw_upgrade == "1")?>var func_fw_upgrade = 1;<?else_node?>var func_fw_upgrade = 0;<?endif_node?>
<?if_node(/runtime/function/wizard == "1")?>var func_wizard = 1;<?else_node?>var func_wizard = 0;<?endif_node?>
<?if_node(/runtime/function/easymesh == "1")?>var func_easymesh = 1;<?else_node?>var func_easymesh = 0;<?endif_node?>
<?if_node(/runtime/function/inndamesh == "1")?>var func_inndamesh = 1;<?else_node?>var func_inndamesh = 0;<?endif_node?>
<?if_node(/runtime/function/WiFiSniffer == "1")?>var func_wifiSniffer = 1;<?else_node?>var func_wifiSniffer = 0;<?endif_node?>
<?if_node(/runtime/function/Ser2net == "1")?>var func_Ser2net = 1;<?else_node?>var func_Ser2net = 0;<?endif_node?>
<?if_node(/runtime/function/udpproxy == "1")?>var func_udpxy = 1;<?else_node?>var func_udpxy = 0;<?endif_node?>
<?if_node(/runtime/function/homeplugd == "1")?>var func_homeplug = 1;<?else_node?>var func_homeplug = 0;<?endif_node?>
<?if_node(/runtime/function/wgd == "1")?>var func_wgd = 1;<?else_node?>var func_wgd = 0;<?endif_node?>
var filenameExp=/:\/\/\S*\/(\S*).htm\??/;
var result=document.location.href.match(filenameExp);
var xgiFilename=result[1]+".xgi?"; /* we need the variable in all web pages; */
var thisFilename=result[1]+".htm"; /* we need the variable in all web pages; */
var baseFilename=result[1];        /* we need the variable in all web pages; */
var folderExp=/:\/\/\S*\/(\S*)\/\S*.htm\??/;
var result2=document.location.href.match(folderExp);
var thisdirectory="";
var topMenuItem=-1;
var customer = "<?ConfigGet(/runtime/web/logo)?>";
var logo_customer = "<?ConfigGet(/runtime/web/logo_customer)?>";
var currentUserGroup = "<?ConfigGet(/runtime/loginlevel)?>";
if(currentUserGroup=="")
currentUserGroup=4;
currentUserGroup=parseInt(currentUserGroup);
Cgroup=parseInt(currentUserGroup);
if(result2)
thisdirectory=result2[1];
function get_sessionKey()
{
var  i = Math.random();
var seknum="";
//return send_requestSession("/advanced/conSession.htm?id="+i);
$.ajax({
type: "GET",
url: "/advanced/conSession.htm?id="+i,
dataType: "text",
async:false,
success: function(msg){
seknum=msg;
},
error:function(){}
});
return seknum;
}
</script>
<?Include(js/common/tree_ISK.js)?>
