function BrowserCheck() {
var b = navigator.appName;
if (b=="Netscape") this.b = "ns";
else if (b=="Microsoft Internet Explorer") this.b = "ie";
else if (b=="Opera") this.b = "opera";
else this.b = b;
this.version = navigator.appVersion;
this.v = parseInt(this.version);
this.ns = (this.b=="ns" && this.v>=4);
this.ns4 = (this.b=="ns" && this.v==4);
this.ns5 = (this.b=="ns" && this.v==5);
this.ie = (this.b=="ie" && this.v>=4);
this.opera = (this.b=="opera");
this.ie4 = (this.version.indexOf('MSIE 4')>0);
this.ie5 = (this.version.indexOf('MSIE 5')>0);
this.ie6 = (this.version.indexOf('MSIE 6')>0);//joe add
this.mac = (this.version.indexOf('Macintosh')>0);
this.min = (this.ns||this.ie ||this.opera);
}
is = new BrowserCheck();
function showhide(element, sh, arg)
{
if (sh == 1)
DisplayShow(element, arg);
else
DisplayHide(element);
}
function DisplayShow(element, arg)
{
$("#"+element).show();
}
function DisplayHide(element)
{
$("#"+element).hide();
}
function changeBlockState(idname,status){
var i,currentcolor;
var tempelems = document.getElementById(idname).getElementsByTagName("*");
if (status == false)
currentcolor = "black";
else
currentcolor = "#aca899";
for (i = 0; i < tempelems.length;i++){
if (tempelems[i].disabled != undefined)
tempelems[i].disabled = status;
if(is.ie){      //ie returns null, firefox uses undefined.
if (tempelems[i].style.color)
tempelems[i].style.color = currentcolor;
}
else{
if (tempelems[i].style.color != undefined && tempelems[i].style.color !="")
tempelems[i].style.color = currentcolor;
}
}
var tempelems = document.getElementById(idname);
if (tempelems.disabled != undefined)
tempelems.disabled = status;
if(is.ie){      //ie returns null, firefox uses undefined.
if (tempelems.style.color)
tempelems.style.color = currentcolor;
}
else{
if (tempelems.style.color != undefined && tempelems.style.color !="")
tempelems.style.color = currentcolor;
}
}
