function doValidateDomain(domain)
{
var intflag = 0;
var dianflag = 0;
var InValidIp=new Array("999.999.999.999","11.0.0.0","129.1.0.0","193.1.1.0","11.255.255.255","129.1.255.255","193.1.1.255","11.127.255.255","224.0.0.1","239.0.0.1","240.0.0.1","254.0.0.1","127.0.0.1");
for(var i=0;i<InValidIp.length;i++)
{
if(domain.value == InValidIp[i])
return false;
}
for (i=0;i<domain.value.length;i++)
{
if(domain.value.charAt(i) == ".")
{
dianflag++;
continue;
}
else
{
if (domain.value.charAt(i) < '0' || domain.value.charAt(i) > '9')
intflag++;
}
}
if((dianflag == 3)&&(intflag == 0))//if the string only include number and the number of "." is 3,check it as ip.
{
if(!valDoValidateIP(domain))
return false;
}
return true;
}
function getIP(ip)
{
var myIP=new Array();
if ( ip != "")
{
var tmp=ip.split(".");
for (var i=1;i <= tmp.length;i++)
{
myIP[i]=tmp[i-1];
}
myIP[0]=ip;
}
else
{
for (var i=1;i <= 4;i++)
{
myIP[i]="";
}
myIP[0]="";
}
return myIP;
}
function isFirewallValidIpAddr(ip1,ip2,ip3,ip4)
{
if(ip1==0 || ip4==255 || ip1==127)
return false;
return true;
}
function valIPtoNetwork(Ip,Subnetmask)
{
var ip = Ip.split(".");
var subnetmask = Subnetmask.split(".");
var a = ip[3];			//Dividend
var b = 256-subnetmask[3];	//Divisor
var c = 0;			//Quotient
var d = 0;
var network = "";
c = Math.floor(a/b);
d = c*b
network = ip[0]+"."+ip[1]+"."+ip[2]+"."+d.toString();
return network;
}
function getIPrange(hostCIDR,hostIP,inputCIDR,inputIP)
{
var hcidr = hostCIDR;
var hip = hostIP.split(".");
var icidr = inputCIDR;
var iip = inputIP.split(".");
var rangeMin = parseInt(hip[3]);
var rangeMax = 0;
//alert("hip="+hip[0]+"."+hip[1]+"."+hip[2]+"."+hip[3]);
//alert("iip="+iip[0]+"."+iip[1]+"."+iip[2]+"."+iip[3]);
//alert("iCIDR="+icidr);
if(((hip[0] == iip[0]) == true && (hip[1] == iip[1]) == true && (hip[2] == iip[2]) == true) && ((icidr == "32") == true || (icidr >= hcidr) == true))
{
if(hcidr == 30)
{
rangeMax = parseInt(rangeMin)+4;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 29)
{
rangeMax = parseInt(rangeMin)+8;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 28)
{
rangeMax = parseInt(rangeMin)+16;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 27)
{
rangeMax = parseInt(rangeMin)+32;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 26)
{
rangeMax = parseInt(rangeMin)+64;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 25)
{
rangeMax = parseInt(rangeMin)+128;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
if(hcidr == 24)
{
rangeMax = parseInt(rangeMin)+256;
if((iip[3] > rangeMin) == true && (iip[3] < rangeMax) == true)
return false;
}
}
return true;
}
function valFirewallDoValidateIP(ctrl)
{
var Address = ctrl.value;
if(Address=="")
{
return false;
}
var address = Address.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
var digits;
if(address == null)
{
return false;
}
else
{
digits = address[0].split(".");
if(digits.length != 4)
return false;
for(var i=0; i < 4; i++)
{
if((Number(digits[i]) > 255 ) || (Number(digits[i]) < 0 ) || (Number(digits[0]) > 223))
{
return false;
break;
}
}
//test(digits[0]);
if(!isFirewallValidIpAddr(digits[0],digits[1],digits[2],digits[3]))
{
return false;
}
}
return true;
}
function isValidStaticIpAddr(ip1)
{
if(ip1==0 || ip1==127)
return false;
return true;
}
function valDoValidateStaticIP(ctrl)
{
var Address = ctrl.value;
if(Address=="")
{
return false;
}
var address = Address.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
var digits;
if(address == null)
{
return false;
}
else
{
digits = address[0].split(".");
if(digits.length != 4)
return false;
for(var i=0; i < 4; i++)
{
if((Number(digits[i]) > 255 ) || (Number(digits[i]) < 0 ) || (Number(digits[0]) > 223))
{
return false;
break;
}
}
if(!isValidStaticIpAddr(digits[0]))
{
return false;
}
}
return true;
}
function isValidIpAddr(ip1,ip2,ip3,ip4)
{
if(ip1==0 || ip4==0 || ip4==255 || ip1==127)
return false;
return true;
}
function valDoValidateIP(ctrl)
{
var Address = ctrl.value;
if(Address=="")
{
return false;
}
var address = Address.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
var digits;
if(address == null)
{
return false;
}
else
{
digits = address[0].split(".");
if(digits.length != 4)
return false;
for(var i=0; i < 4; i++)
{
if((Number(digits[i]) > 255 ) || (Number(digits[i]) < 0 ) || (Number(digits[0]) > 223))
{
return false;
break;
}
}
if(!isValidIpAddr(digits[0],digits[1],digits[2],digits[3]))
{
return false;
}
}
return true;
}
function IpBetween(Address, ip1start, ip1end, ip2start, ip2end)
{
var inrange=1,inrange1=1,inrange2=1;
var digits=ip1start.split(".");
var digite=ip1end.split(".");
var digit=Address.split(".");
if(ip2start == "" || ip2end == "")
{
for ( var i=0;i<4;i++)
{
if( ( parseInt(digit[i]) < parseInt(digits[i]) ) || ( parseInt(digit[i]) > parseInt(digite[i]) ) )
{
inrange=0;
break;
}
}
}
else
{
var tmpdigits=ip2start.split(".");
var tmpdigite=ip2end.split(".");
for ( var i=0;i<4;i++)
{
if( ( parseInt(digit[i]) < parseInt(digits[i]) ) || ( parseInt(digit[i]) > parseInt(tmpdigits[i]) ) )
{
inrange1=0;
break;
}
}
for ( var i=0;i<4;i++)
{
if( ( parseInt(digit[i]) < parseInt(digite[i]) ) || ( parseInt(digit[i]) > parseInt(tmpdigite[i]) ) )
{
inrange2=0;
break;
}
}
if(inrange1 == 0 && inrange2 == 0)
inrange = 0;
}
if( inrange==0 )
return false;
else
return true;
}
function doValidateIpBetween(ctrl, ipstart, ipend, lanip)
{
var Address=ctrl.value;
var tmpIPEnd = "";
var tmpIPStart = "";
var tmp = lanip.split(".");
var msg1="";
var msg2="";
if(lanip == ipstart)
{
ipstart=tmp[0]+"."+tmp[1]+"."+tmp[2]+"."+(parseInt(tmp[3])+1);
if( IpBetween(Address, ipstart, ipend, tmpIPStart, tmpIPEnd) ==false)
{
msg1 = m_ip_range +ipstart+" - "+ipend;
dx_alert_error_message( ctrl, msg1);
return false;
}
}
else if(lanip == ipend)
{
ipend=tmp[0]+"."+tmp[1]+"."+tmp[2]+"."+(parseInt(tmp[3])-1);
if (IpBetween(Address, ipstart, ipend, tmpIPStart, tmpIPEnd) ==false)
{
msg1 = m_ip_range +ipstart+" - "+ipend;
dx_alert_error_message( ctrl, msg1);
return false;
}
}
else if(Address == lanip)
{
dx_alert_error_message( ctrl, "The Address can't equal LAN ip");
return false;
}
else
{
tmpIPEnd = tmp[0]+"."+tmp[1]+"."+tmp[2]+"."+(parseInt(tmp[3])+1);
tmpIPStart = tmp[0]+"."+tmp[1]+"."+tmp[2]+"."+(parseInt(tmp[3])-1);
if (IpBetween(Address, ipstart, tmpIPStart,tmpIPEnd,ipend) ==false)
{
if(ipstart == tmpIPStart)
msg1 = m_ip_range +ipstart;
else
msg1 = m_ip_range +ipstart+" - "+tmpIPStart;
if(tmpIPEnd == ipend)
msg2 = m_or +tmpIPEnd;
else
msg2 = m_or +tmpIPEnd+" - "+ipend;
dx_alert_error_message( ctrl, msg1+msg2);
return false;
}
}
}
function Isnumber(ctrl, item)
{
var Arg=ctrl.value;
var msg;
if (Arg=="")
{
msg=item+ m_numeric;
dx_alert_error_message( ctrl, msg);
return false;
}
var len=Arg.length;
var re = new RegExp("^[0-9]{1,"+Arg.length+"}$", "g");
if (!re.test(Arg))
{
msg=item+ m_numeric;
dx_alert_error_message( ctrl, msg);
return false;
}
else
{
return true;
}
}
function doValidateMac(Address)
{
Address = Address.replace(/\-/g, ":");
var address=Address.match("^[0-9,a-f,A-F]{2}\:[0-9,a-f,A-F]{2}\:[0-9,a-f,A-F]{2}\:[0-9,a-f,A-F]{2}\:[0-9,a-f,A-F]{2}\:[0-9,a-f,A-F]{2}$");
var digits;
var i;
if(address == null)
{
return false;
}
digits=address[0].split(":");
if(digits.length != 6)
{
return false;
}
return true;
}
function doValidateMask(ctrl)
{
var mask = ctrl.value.match("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$");
var digits;
var bMask = 0;
var watch = false;
var i;
if(mask == null)
{
return false;
}
if(ctrl.value == "255.255.255.253" || ctrl.value == "0.0.0.0")
return false;
digits = mask[0].split(".");
if(digits.length != 4)
return false;
for(i=0; i < 4; i++)
{
if((Number(digits[i]) > 255 ) || (Number(digits[i]) < 0 ) ||  (Number(digits[i]) == 1 ))
{
return false;
}
bMask = (bMask << 8) | Number(digits[i]);
}
bMask = bMask & 0x0FFFFFFFF;
for(i=0; i<32; i++)
{
if((watch==true) && ((bMask & 0x1)==0))
{
return false;
}
bMask = bMask >> 1;
if((bMask & 0x01) == 1)
watch=true;
}
return true;
}
function doValidateRange(startCtrl,endCtrl)
{
var startIP=startCtrl.value;
var endIP=endCtrl.value;
var staddress;
var edaddress;
var cnt;
staddress=startIP.split(".");
edaddress=endIP.split(".");
for(cnt=0; cnt < 4; cnt++)
{
if(Number(staddress[cnt])<Number(edaddress[cnt]))
return true;
if(Number(edaddress[cnt])<Number(staddress[cnt]))
{
dx_alert_error_message(startCtrl, m_end_less_start);
return false;
}
}
return true;
}
function dx_alert_error_message( ctrl, msg)
{
alert( msg);
ctrl.focus();
ctrl.select();
}
function getLeftMostZeroBitPos(num)
{
var i = 0;
var numArr = [128, 64, 32, 16, 8, 4, 2, 1];
for ( i = 0; i < numArr.length; i++ )
if ( (num & numArr[i]) == 0 )
{
return i;
}
return numArr.length;
}
function getRightMostOneBitPos(num)
{
var i = 0;
var numArr = [1, 2, 4, 8, 16, 32, 64, 128];
for ( i = 0; i < numArr.length; i++ )
if ( ((num & numArr[i]) >> i) == 1 )
{
return (numArr.length - i - 1);
}
return -1;
}
function isValidMacMask(mask)
{
var c = '';
var num = 0;
var i = 0, j = 0;
var zeros = 0;
var zeroBitPos = 0, oneBitPos = 0;
var zeroBitExisted = false;
mask = mask.replace(/\-/g, ":");
maskParts = mask.split(':');
if ( maskParts.length != 6 )
return false;
for (i = 0; i < 6; i++)
{
if ( maskParts[i] == '' )
return false;
for ( j = 0; j < maskParts[i].length; j++ )
{
c = maskParts[i].toLowerCase().charAt(j);
if ( (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') )
continue;
else
return false;
}
num = parseInt(maskParts[i], 16);
if ( num == NaN || num < 0 || num > 255 )
return false;
if ( zeroBitExisted == true && num != 0 )
return false;
if ( num == 0 )
zeros++;
zeroBitPos = getLeftMostZeroBitPos(num);
oneBitPos = getRightMostOneBitPos(num);
if ( zeroBitPos < oneBitPos )
return false;
if ( zeroBitPos < 8 )
zeroBitExisted = true;
}
if (zeros == 6)
return false;
return true;
}
function netmaskToCIDR(mask)
{
var maskNodes = mask.match(/(\d+)/g);
var cidr = 0;
for(var i in maskNodes)
{
cidr += (((maskNodes[i] >>> 0).toString(2)).match(/1/g) || []).length;
}
return cidr;
}
function CIDRToNetmask(cidr)
{
var mask=[];
for(i=0;i<4;i++)
{
var n = Math.min(cidr, 8);
mask.push(256 - Math.pow(2, 8-n));
cidr -= n;
}
return mask.join('.');
}
